public class Variavel extends Gastos {
    public Variavel(String nome, double valor) {
        super(nome, valor);
    }

}
