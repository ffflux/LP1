public class Fixo extends Gastos {
    public Fixo(String nome, double valor) {
        super(nome, valor);
    }
}
